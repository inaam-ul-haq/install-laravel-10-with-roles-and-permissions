<x-guest-layout pageTitle="Verify your account">
    Verify your email first
</x-guest-layout>
