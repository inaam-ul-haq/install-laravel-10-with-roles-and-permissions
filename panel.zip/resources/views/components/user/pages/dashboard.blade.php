<!-- Content Row -->
<div class="row">

    <div class="col-xl-12 col-md-12 mb-4">
        <x-front.card>
            This is user dashboard
        </x-front.card>
    </div>

</div>
