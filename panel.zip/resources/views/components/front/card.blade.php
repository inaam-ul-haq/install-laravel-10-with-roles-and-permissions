<div class="card border-bottom-primary shadow h-100 py-2">
    <div class="card-body">
        {{ $slot }}
    </div>
</div>
