@include('layouts.links')

@include('layouts.guest-nav')

{{ $slot }}

@include('layouts.footer')
