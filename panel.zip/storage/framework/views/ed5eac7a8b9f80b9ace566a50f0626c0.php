<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve(['pageTitle' => 'Register'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-6 mx-auto">
                <?php if (isset($component)) { $__componentOriginalb371be319679de19de1cbc7cda7717e0 = $component; } ?>
<?php $component = App\View\Components\Front\Card::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('front.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Front\Card::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                    <h2 class="text-center"> Create your Account</h2>
                    <form method="POST" action="<?php echo e(route('register')); ?>" class="row g-1">
                        <?php echo csrf_field(); ?>
                        <div class="col-md-12" style="position: relative;top: 5px;">
                            <label class="form-label" id="label-form">Full name</label>
                            <div class="section space long-value-input-container">
                                <input type="text" required class="long-value-input" name="name"
                                    style="padding-right: 40px" />
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-12" style="position: relative;top: 20px;">
                            <label>Username</label>
                            <div class="section space long-value-input-container">
                                <input id="password-field" type="text" class="long-value-input pass"
                                    name="username">
                                <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-12" style="position: relative;top: 30px;">
                            <label>Email</label>
                            <div class="section space long-value-input-container">
                                <input id="password-field" type="email" class="long-value-input"
                                    class="pass" name="email" value="<?php echo e(old('email')); ?>">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-12" style="position: relative;top: 40px;">
                            <label>Password</label>
                            <div class="section space long-value-input-container">
                                <input id="password-field" type="password" class="long-value-input"
                                    class="pass" name="password">
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-12" style="position: relative;top: 40px;">
                            <label> Repeat Password</label>
                            <div class="section space long-value-input-container">
                                <input id="password-field" type="password" class="long-value-input"
                                    value="" class="pass" name="password_confirmation" required
                                    autocomplete="new-password">
                            </div>
                        </div>
                        <div class="col-md-12" style="position: relative;top: 40px;">
                            <label> Repeat Password</label>
                            <div class="section space long-value-input-container">
                                <select name="role" id="role">
                                    <option value="particular">particular</option>
                                    <option value="professional">professional</option>
                                </select>
                            </div>
                        </div>

                        <div class="col-md-12" style="position: relative;top: 70px;">
                            <button class="btn2  btn-enter  form-control1" type="submit"> Register</button>

                            <div style="text-align:center;" class="mt-4">
                                <img src="<?php echo e(url('frontend\img\headerbanner\1.png')); ?>" alt="">
                                <img src="<?php echo e(url('frontend\img\headerbanner\2.png')); ?>" alt="">
                                <img src="<?php echo e(url('frontend\img\headerbanner\3.png')); ?>" alt="">
                            </div>

                            <div class="d-flex justify-content-center signupbtn">
                                <div>
                                    <span class="account " style="font-size: small;">Have an account already?
                                    </span>
                                    <a href="<?php echo e(route('login')); ?>" class="signup"> Signin</a>
                                </div>
                            </div>
                        </div>
                    </form>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb371be319679de19de1cbc7cda7717e0)): ?>
<?php $component = $__componentOriginalb371be319679de19de1cbc7cda7717e0; ?>
<?php unset($__componentOriginalb371be319679de19de1cbc7cda7717e0); ?>
<?php endif; ?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php /**PATH E:\Al Right\electronics purchase\panel\resources\views/auth/register.blade.php ENDPATH**/ ?>