<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve(['pageTitle' => 'Login'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('styles'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>" />
    <?php $__env->stopSection(); ?>

    <div class="container py-5">
    <div class="row py-5">
      <div class="col-md-3"></div>

      <div class="col-md-6 loginmain py-2">
        <div class="text-center p-2 p-md-5">
          <div class="pb-4 logincontet">
            <h3>Log In</h3>

            <p>
              Hey there, Enter your details to <br />
              Log In to your account
            </p>
          </div>
            <form method="POST" action="<?php echo e(route('login')); ?>" class="row g-1">
                <?php echo csrf_field(); ?>
                <div class="work-card worksection getintouchform">
                    <div class="my-2">
                        <input type="text" name="email" placeholder="Email" />
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <strong><?php echo e($message); ?></strong>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="my-5">
                        <input type="text" name="password" placeholder="Password" />
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <strong><?php echo e($message); ?></strong>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <a href="<?php echo e(route('password.request')); ?>" class="float-end mt-3 text-decoration-none">Forgot Password?</a>
                    </div>

                    <div class="pt-5">
                        <div class="main-content">
                            <button type="submit" class="btn btn-sm px-5">Login</button>
                        </div>

                        <div class="mt-3">
                            <p>
                            Don’t Have Account ?<a href="<?php echo e(route('register')); ?>" class="mt-3 text-decoration-none">Sign Up</a>
                            </p>
                        </div>
                    </div>
                </div>
            </form>
        </div>
      </div>
      <div class="col-md-3"></div>
    </div>
  </div>
    <!-- Login Section End  -->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php /**PATH E:\Al Right\electronics purchase\panel\resources\views/auth/login.blade.php ENDPATH**/ ?>