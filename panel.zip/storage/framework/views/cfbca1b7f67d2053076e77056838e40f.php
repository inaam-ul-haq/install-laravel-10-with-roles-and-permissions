<!-- Content Row -->
<div class="row">

    <div class="col-xl-12 col-md-12 mb-4">
        <?php if (isset($component)) { $__componentOriginalb371be319679de19de1cbc7cda7717e0 = $component; } ?>
<?php $component = App\View\Components\Front\Card::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('front.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Front\Card::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            This is admin dashboard
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb371be319679de19de1cbc7cda7717e0)): ?>
<?php $component = $__componentOriginalb371be319679de19de1cbc7cda7717e0; ?>
<?php unset($__componentOriginalb371be319679de19de1cbc7cda7717e0); ?>
<?php endif; ?>
    </div>

</div>
<?php /**PATH E:\Al Right\electronics purchase\panel\resources\views/components/admin/pages/dashboard.blade.php ENDPATH**/ ?>