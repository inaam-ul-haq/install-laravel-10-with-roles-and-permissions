<div class='input-group has-validation'>
    <input type='<?php echo e($type); ?>' class='form-control <?php echo e($extraclasses); ?> <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>' id='<?php echo e($id); ?>'
        name='<?php echo e($name); ?>' placeholder='<?php echo e($place); ?>' <?php echo e($extraAttributes); ?> <?php echo e($required == null ? '' : 'required'); ?>

        value='<?php echo e($val == '' ? old($name) : $val); ?>'>

    <div class='valid-feedback'>
        Looks good!
    </div>
    <div class='invalid-feedback'>
        <?php if($errors->has($name)): ?>
            <?php echo e($errors->first($name)); ?>

        <?php else: ?>
            Please choose <?php echo e($name); ?>.
        <?php endif; ?>
    </div>
</div>
<?php /**PATH E:\Al Right\electronics purchase\panel\resources\views/components/input-field.blade.php ENDPATH**/ ?>