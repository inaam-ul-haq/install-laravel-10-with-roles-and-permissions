<?php echo $__env->make('layouts.auth_links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.auth_top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo e($slot); ?>


<!-- Footer -->
<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span> <?php echo e(config('app.name')); ?> Copyright &copy; <?php echo e(date('Y')); ?></span>
        </div>
    </div>
</footer>
<!-- End of Footer -->
</div>

<?php echo $__env->make('layouts.auth_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH E:\Al Right\electronics purchase\panel\resources\views/components/auth-layout.blade.php ENDPATH**/ ?>