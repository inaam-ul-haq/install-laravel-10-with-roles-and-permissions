<div class="card border-bottom-primary shadow h-100 py-2">
    <div class="card-body">
        <?php echo e($slot); ?>

    </div>
</div>
<?php /**PATH E:\Al Right\electronics purchase\panel\resources\views/components/front/card.blade.php ENDPATH**/ ?>